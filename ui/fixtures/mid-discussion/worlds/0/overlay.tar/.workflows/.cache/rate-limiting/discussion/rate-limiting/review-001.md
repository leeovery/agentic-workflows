# Discussion Review — review-001

## Summary

Early-stage discussion — three of four mapped subtopics are still `pending`, with only `limiter-scope` decided. The limiter-scope decision itself is well-formed (concrete symptom, options with trade-offs, an explicit note on what was deliberately deferred). At this stage findings are fuel for what's still ahead, not defects in what exists.

## Gaps Identified

None identified.

## Open Questions

### F1: Behaviour when the bucket is exhausted

**Lane:** ask

None of the four mapped subtopics (`token-bucket-limiter`, `limiter-scope`, `retry-backoff-strategy`, `429-retry-budget`) currently covers what the client does when a request arrives and its host's bucket has no tokens available: does the call block/await until a token refills, queue with a timeout, or fail fast and let the caller retry? This shapes the limiter's API surface (sync rejection vs. async wait) and is worth raising before `token-bucket-limiter` is documented.

### F2: Interaction between backoff and the per-host bucket

**Lane:** ask

`retry-backoff-strategy` and the now-decided per-host `limiter-scope` both govern the same retry path but their interaction hasn't been raised: when a retry's exponential backoff delay elapses, does the retry then draw from the same per-host bucket as fresh requests (potentially queuing again if the bucket is still empty), or does backoff operate independently of the bucket? Left unaddressed, the two mechanisms could end up fighting each other — a long backoff sleep followed by an immediate limiter block.

## Observations

- The Context section's two open questions (per-host vs. global; 429s against retry budget) are current — the first is now decided, the second is a pending subtopic (`429-retry-budget`), so no correction is needed there.
- Concurrency/thread-safety of the bucket implementation was not raised — likely a non-issue in Node's single-threaded event loop, but worth a one-line confirmation if the client is ever used with worker threads.
