# Discovery Session 001

Date: 2026-08-26
Work unit: rate-limiting

## Description (as of session)

Add rate limiting (token-bucket, configurable req/s) and exponential backoff on retries to the API client (src/client.js).

## Seed

(none)

## Imports

(none)

## Map State at Start

(n/a — single-topic work)

## Exploration

The user wants to add rate limiting to the API client in `src/client.js`. Currently `getWithRetry` retries immediately with no backoff, and there is no throttle on concurrent requests. The proposed direction is a token-bucket limiter with configurable requests-per-second, plus exponential backoff on retries. Two open questions surfaced that belong to a later phase rather than shape: whether the limiter should be scoped per-host or global, and whether 429 responses should count against the retry budget. The shape was confirmed as a single coherent feature — one component, clear scope, no competing signals for a broader initiative or a bugfix.

## Edits

(none)

## Topics Identified

(none)

## Conclusion

(none)
